import '../css/bootstrap.min.css'
import '../css/style.css'

document.querySelector('#app').innerHTML = "<h1>Hello RubyJS</h1>"
